<?php

global $_LANG;
$_LANG = array();

$_LANG['cms_d3c42ceb9bee8c44815b53f36e496925'] = 'List of subcategories in %s:';
$_LANG['live_edit_79030d996976f29a5e986a42d8f026e5'] = 'Unable to save the module\'s position';
$_LANG['live_edit_d8dcfab18b3a6eba56d617dd1dcb1ba7'] = 'Close LiveEdit';
$_LANG['live_edit_da87eac3848a0d55560bdd129a0e134b'] = 'Unable to unregister the hook';
$_LANG['order-carrier_0a5737e9ac4d4cdbf41e473674c0e557'] = 'I agree to the terms of service and will adhere to them unconditionally.';
$_LANG['order-detail_6332e7985befad227455d60812bd1449'] = 'Order Reference %s -- placed on';
$_LANG['order-payment_1d4c9008fd49770971ffc2e8f32df870'] = 'Total shipping (tax incl.)';
$_LANG['order-payment_2633d6725607d13e80f5e30514b91fbe'] = 'Total vouchers';
$_LANG['order-payment_28e014bf2ccc53bc1a8042ca57ca6645'] = 'Total vouchers (tax incl.)';
$_LANG['order-payment_29cfbfc41066134782f966beefd63a4e'] = 'Total products (tax incl.)';
$_LANG['order-payment_3a5199ec2407f4b2f90496072ea8f006'] = 'Total products (tax excl.)';
$_LANG['order-payment_4e59b98d7fa1d964bfd9841ad5c34980'] = 'Total vouchers (tax excl.)';
$_LANG['order-payment_543ae6adeb524f98cc7d3c816a1ec1e3'] = 'Total products';
$_LANG['order-payment_66c4c5112f455a19afde47829df363fa'] = 'Total';
$_LANG['order-payment_691b338fa68b3c177c6ebbc745624c6a'] = 'Total shipping';
$_LANG['order-payment_9a7dfcdac1fa244d3ddb36a9c0662c9e'] = 'Total shipping (tax excl.)';
$_LANG['order-payment_b935a8c55ff8c1c967d6f848b375db81'] = 'Total gift wrapping (tax incl.)';

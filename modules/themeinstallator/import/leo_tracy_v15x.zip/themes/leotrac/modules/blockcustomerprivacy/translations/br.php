<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Bloco de privacidade de dados do cliente';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Adiciona um bloco para mostrar uma mensagem sobre a privacidade dos dados dos clientes.';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Os dados pessoais são usados ​​para responder às suas perguntas, processar as suas encomendas ou permitir o acesso a informações específicas.';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Você tem o direito de modificar e apagar todas as informações pessoais que possuímos sobre você. Só entrar na pagina de login e ir em \"minha conta\".';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurações atualizadas.';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Mensagem para a privacidade dos dados dos clientes';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Mensagem que será exibida no formulário de criação da conta.';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Dicas: Lembre-se que se o texto é muito longo para ser escrito diretamente no formulário, você pode adicionar um link para uma de suas páginas criadas através do \"CMS\" página sob o menu \"Preferências\".';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Por favor, concordar com a privacidade dos dados dos clientes, assinalando a caixa de seleção abaixo.';
$_MODULE['<{blockcustomerprivacy}leotrac>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacidade de dados dos clientes';

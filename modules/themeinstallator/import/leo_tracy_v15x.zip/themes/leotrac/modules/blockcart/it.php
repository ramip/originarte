<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcart}leotrac>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Personalizzazione n°';
$_MODULE['<{blockcart}leotrac>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'rimuovi questo prodotto dal mio carrello';
$_MODULE['<{blockcart}leotrac>blockcart_c6995d6cc084c192bc2e742f052a5c74'] = 'Spedizione gratuita!';
$_MODULE['<{blockcart}leotrac>blockcart_e7a6ca4e744870d455a57b644f696457'] = 'Gratis!';
$_MODULE['<{blockcart}leotrac>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Elimina';
$_MODULE['<{blockcart}leotrac>blockcart_0c3bf3014aafb90201805e45b5e62881'] = 'Vedi il mio carrello';
$_MODULE['<{blockcart}leotrac>blockcart_b75443a19207ed3a3552edda86536857'] = 'Carrinho de Compras';
$_MODULE['<{blockcart}leotrac>blockcart_86024cad1e83101d97359d7351051156'] = 'prodotti';
$_MODULE['<{blockcart}leotrac>blockcart_f5bf48aa40cad7891eb709fcf1fde128'] = 'prodotto';
$_MODULE['<{blockcart}leotrac>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vuoto)';
$_MODULE['<{blockcart}leotrac>blockcart_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Dettaglio prodotto';
$_MODULE['<{blockcart}leotrac>blockcart_3d9e3bae9905a12dae384918ed117a26'] = 'Personalizzazione #%d:';
$_MODULE['<{blockcart}leotrac>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Nessun prodotto';
$_MODULE['<{blockcart}leotrac>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Spedizione';
$_MODULE['<{blockcart}leotrac>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Imballaggio';
$_MODULE['<{blockcart}leotrac>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Tasse';
$_MODULE['<{blockcart}leotrac>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Totale';
$_MODULE['<{blockcart}leotrac>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'I prezzi sono IVA inclusa';
$_MODULE['<{blockcart}leotrac>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'I prezzi sono IVA esclusa';
$_MODULE['<{blockcart}leotrac>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrello';
$_MODULE['<{blockcart}leotrac>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Check out';

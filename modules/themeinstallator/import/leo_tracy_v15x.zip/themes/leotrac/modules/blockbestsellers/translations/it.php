<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Di più';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_adc570b472f54d65d3b90b8cee8368a9'] = 'Non ci sono migliori vendite in questo momento';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_ee520a08f4b3f527b11c4316aa399e84'] = 'Blocco migliori vendite';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_4f6db60ed6f1c8555648014427822faf'] = 'Aggiungi un blocco che mostra le migliori vendite del negozio.';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_41385d2dca40c2a2c7062ed7019a20be'] = 'Visualizza sempre blocco.';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Mostra il blocco anche se nessun prodotto è disponibile.';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Guarda i prodotti più venduti';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Non ci sono migliori vendite in questo momento';
$_MODULE['<{blockbestsellers}leotrac>blockbestsellers-home_f7be84d6809317a6eb0ff3823a936800'] = 'Non ci sono migliori vendite in questo momento';

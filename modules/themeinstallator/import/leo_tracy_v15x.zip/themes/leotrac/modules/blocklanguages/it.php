<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}leocame>blocklanguages_2575f2a453fd18a4e74e430a80eb3540'] = 'Aggiunge un blocco selezionare una lingua';
$_MODULE['<{blocklanguages}leocame>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Blocco lingua';

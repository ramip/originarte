<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklayered}leotrac>blocklayered_c32516babc5b6c47eb8ce1bfc223253c'] = 'Katalog';
$_MODULE['<{blocklayered}leotrac>blocklayered_1262d1b9fbffb3a8e85ac9e4b449e989'] = 'Aktivierte Filter:';
$_MODULE['<{blocklayered}leotrac>blocklayered_ea4788705e6873b424c65e91c2846b19'] = 'Abbrechen';
$_MODULE['<{blocklayered}leotrac>blocklayered_853ae90f0351324bd73ea615e6487517'] = ':';
$_MODULE['<{blocklayered}leotrac>blocklayered_b47b72ddf8a3fa1949a7fb6bb5dbc60c'] = 'Keine Filter';
$_MODULE['<{blocklayered}leotrac>blocklayered_75954a3c6f2ea54cb9dff249b6b5e8e6'] = 'Range:';
$_MODULE['<{blocklayered}leotrac>blocklayered_5da618e8e4b89c66fe86e32cdafde142'] = 'Von';
$_MODULE['<{blocklayered}leotrac>blocklayered_01b6e20344b68835c5ed1ddedf20d531'] = 'Empfänger';
$_MODULE['<{blocklayered}leotrac>blocklayered_146ffe2fd9fa5bec3b63b52543793ec7'] = 'Mehr anzeigen';
$_MODULE['<{blocklayered}leotrac>blocklayered_c74ea6dbff701bfa23819583c52ebd97'] = 'Weniger anzeigen';
$_MODULE['<{blocklayered}leotrac>blocklayered_8524de963f07201e5c086830d370797f'] = 'Lädt...';

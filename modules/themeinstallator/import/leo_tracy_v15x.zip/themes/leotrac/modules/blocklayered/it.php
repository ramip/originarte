<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklayered}leotrac>blocklayered_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalogo';
$_MODULE['<{blocklayered}leotrac>blocklayered_1262d1b9fbffb3a8e85ac9e4b449e989'] = 'Filtri abilitati:';
$_MODULE['<{blocklayered}leotrac>blocklayered_ea4788705e6873b424c65e91c2846b19'] = 'Annulla';
$_MODULE['<{blocklayered}leotrac>blocklayered_853ae90f0351324bd73ea615e6487517'] = ':';
$_MODULE['<{blocklayered}leotrac>blocklayered_b47b72ddf8a3fa1949a7fb6bb5dbc60c'] = 'Nessun filtro';
$_MODULE['<{blocklayered}leotrac>blocklayered_75954a3c6f2ea54cb9dff249b6b5e8e6'] = 'Raggio d\'azione:';
$_MODULE['<{blocklayered}leotrac>blocklayered_5da618e8e4b89c66fe86e32cdafde142'] = 'Da';
$_MODULE['<{blocklayered}leotrac>blocklayered_01b6e20344b68835c5ed1ddedf20d531'] = 'a';
$_MODULE['<{blocklayered}leotrac>blocklayered_146ffe2fd9fa5bec3b63b52543793ec7'] = 'Mostra di più';
$_MODULE['<{blocklayered}leotrac>blocklayered_c74ea6dbff701bfa23819583c52ebd97'] = 'Mostra meno';
$_MODULE['<{blocklayered}leotrac>blocklayered_8524de963f07201e5c086830d370797f'] = 'Caricamento in corso ...';

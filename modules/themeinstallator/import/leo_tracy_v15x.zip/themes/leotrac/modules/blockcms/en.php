<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcms}prestashop>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Best sellers';
$_MODULE['<{blockcms}prestashop>blockcms_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';

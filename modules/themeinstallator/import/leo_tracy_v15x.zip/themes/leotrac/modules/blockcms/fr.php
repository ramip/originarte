<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}leotrac>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos magasins';
$_MODULE['<{blockcms}leotrac>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{blockcms}leotrac>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Promotions';
$_MODULE['<{blockcms}leotrac>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_MODULE['<{blockcms}leotrac>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockcms}leotrac>blockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
$_MODULE['<{blockcms}leotrac>blockcms_e1da49db34b0bdfdddaba2ad6552f848'] = 'Plan du site';
$_MODULE['<{blockcms}leotrac>blockcms_5813ce0ec7196c492c97596718f71969'] = 'Plan du site';
$_MODULE['<{blockcms}leotrac>blockcms_7a52e36bf4a1caa031c75a742fb9927a'] = 'Propulsé par';

<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_49fa2426b7903b3d4c89e2c1874d9346'] = 'Learn more about';

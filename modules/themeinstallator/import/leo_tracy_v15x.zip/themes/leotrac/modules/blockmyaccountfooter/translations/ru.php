<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Блок Моя учетная запись в подвале';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Отображает блок со ссылками связанными с учетной записью пользователя.';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Управление моей зачетной записью';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Моя учетная запись';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Мои заказы';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'Список моих возвратов товара';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Мои возвраты покупок';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Мои кредитные квитанции';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Мои адреса';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Управление моей личной информацией';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Моя личная информация';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Мои купоны';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'Список моих заказов';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'Список моих возвратов покупок';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'Список моих кредитных квитанций';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'Список моих адресов';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'Список моих купонов';

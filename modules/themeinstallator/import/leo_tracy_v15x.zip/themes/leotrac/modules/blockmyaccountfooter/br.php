<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Gerenciar minha conta de cliente	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'A minha conta	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'Lista dos meus pedidos	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Minhas ordens	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'Lista de volta a minha mercadoria	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Meus retornos de mercadorias	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'Lista de deslizamentos meus crédito	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Meus deslizamentos de crédito	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'Lista dos meus endereços	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Meus endereços	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Gerenciar minhas informações pessoais	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Minha informação pessoal	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'Lista dos meus comprovantes	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Meu vouchers	';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Sair	';

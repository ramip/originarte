<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Bloc Mon compte dans le pied de page';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Affiche un bloc avec des liens relatifs au compte du client.';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Gérer mon compte client';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Mes commandes';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'Voir mes retours produits';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Mes retours de marchandise';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Mes avoirs';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Mes adresses';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Gérer mes informations personnelles';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Mes informations personnelles';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Mes bons de réduction';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Se déconnecter';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'Voir mes commandes';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'Voir mes retours produits';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'Voir mes avoirs';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'Voir mes adresses';
$_MODULE['<{blockmyaccountfooter}leotrac>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'Voir mes réductions';

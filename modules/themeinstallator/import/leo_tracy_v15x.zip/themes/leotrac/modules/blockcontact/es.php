<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leotrac>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Contacte con nosotros';
$_MODULE['<{blockcontact}leotrac>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Nuestra línea directa está disponible 24/7';
$_MODULE['<{blockcontact}leotrac>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Teléfono:';
$_MODULE['<{blockcontact}leotrac>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Póngase en contacto con nuestra línea directa';

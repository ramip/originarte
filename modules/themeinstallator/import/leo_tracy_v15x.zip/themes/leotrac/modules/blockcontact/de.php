<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leotrac>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Kontaktieren Sie uns';
$_MODULE['<{blockcontact}leotrac>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Wir sind 24 Stunden, 7 Tage die Woche, für Sie erreichbar';
$_MODULE['<{blockcontact}leotrac>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefon-Nr.';
$_MODULE['<{blockcontact}leotrac>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Nehmen Sie Kontakt mit uns auf';

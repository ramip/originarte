<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leotrac>blockcontact_0f45a6908556b5b1d7c7d79e60fa3fa7'] = 'Bloco de contato';
$_MODULE['<{blockcontact}leotrac>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Permite inserir informações adicionais para um outro serviço de contato';
$_MODULE['<{blockcontact}leotrac>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurações atualizadas.';
$_MODULE['<{blockcontact}leotrac>blockcontact_17870f54a180e69e60e84125f805db67'] = 'Número de telefone:';
$_MODULE['<{blockcontact}leotrac>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'email';
$_MODULE['<{blockcontact}leotrac>blockcontact_b17f3f4dcf653a5776792498a9b44d6a'] = 'Atualizar configurações';
$_MODULE['<{blockcontact}leotrac>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Fale conosco';
$_MODULE['<{blockcontact}leotrac>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = '           Não encontrou o produto           desejado, envie-nos um           e-mail.';
$_MODULE['<{blockcontact}leotrac>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefone:';
$_MODULE['<{blockcontact}leotrac>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Enviar e-mail';
$_MODULE['<{blockcontact}leotrac>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = '           Não encontrou o produto           desejado, envie-nos um           e-mail.';
$_MODULE['<{blockcontact}leotrac>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Enviar e-mail';
